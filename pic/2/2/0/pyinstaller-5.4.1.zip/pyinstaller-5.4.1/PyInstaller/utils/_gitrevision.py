#
# The content of this file will be filled in with meaningful data when creating an archive using `git archive` or by
# downloading an archive from github, e.g., from github.com/.../archive/develop.zip
#
rev = "36aa18acf2"  # abbreviated commit hash
commit = "36aa18acf2a04a4f28e45f9e805480f0df0c577a"  # commit hash
date = "2022-09-11 11:32:55 +0100"  # commit date
author = "Brénainn Woodsend <bwoodsend@gmail.com>"
ref_names = "tag: v5.4.1"  # incl. current branch
commit_message = """Release v5.4.1. [skip ci]
"""
